from setuptools import setup

setup(
    name='hello',
    version=0.01,
    description='simple hello',
    url='#',  # repository url
    author='Mehran',
    packages=['meow'],
    license='MIT',
    zip_safe=False
)
