def hello():
    print('meow meow')
